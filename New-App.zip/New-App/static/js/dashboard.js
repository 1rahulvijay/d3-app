const themes = [
    'light-theme', 'dark-theme', 'high-contrast-theme', 'pastel-theme', 'solarized-theme',
    'corporate-theme', 'minimal-theme', 'ocean-theme', 'forest-theme', 'neutral-theme',
    'retro-theme', 'vibrant-theme', 'monochrome-theme', 'sunset-theme', 'nord-theme'
];

let currentTheme = 'light-theme';
const chartConfig = {
    defaultWidth: 400,
    defaultHeight: 280,
    margin: { top: 30, right: 20, bottom: 40, left: 40 },
    animationDuration: 3500,
    mobileBreakpoint: 768,
    largeScreenBreakpoint: 1920
};

// Utility Functions
const getCSSVariable = (variable) =>
    getComputedStyle(document.documentElement).getPropertyValue(variable).trim();

const getResponsiveDimensions = (containerId) => {
    const container = document.querySelector(containerId);
    const width = container ? Math.max(container.clientWidth - 20, chartConfig.defaultWidth) : chartConfig.defaultWidth;
    const height = window.innerWidth <= chartConfig.mobileBreakpoint ? 200 :
        (window.innerWidth >= chartConfig.largeScreenBreakpoint ? 320 : chartConfig.defaultHeight);
    return { width, height, fontScale: Math.min(1, width / chartConfig.defaultWidth) };
};

// Data Fetching
const fetchData = async () => {
    const spinners = document.querySelectorAll('.loading-spinner');
    spinners.forEach(spinner => spinner.style.display = 'block');

    try {
        const response = await fetch('/api/data', { cache: 'no-store' });
        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const data = await response.json();
        return data || { lineData: [], barData: [], areaData: [], scatterData: [], metrics: {} };
    } catch (error) {
        console.error('Error fetching data:', error);
        alert('Failed to fetch data. Using fallback data.');
        // Fallback mock data for testing
        return {
            lineData: [
                { label: 'Jan', value: 10 },
                { label: 'Feb', value: 20 },
                { label: 'Mar', value: 15 }
            ],
            barData: [
                { label: 'Jan', value: 15 },
                { label: 'Feb', value: 25 },
                { label: 'Mar', value: 20 }
            ],
            areaData: [
                { label: 'Jan', value: 12 },
                { label: 'Feb', value: 22 },
                { label: 'Mar', value: 18 }
            ],
            scatterData: [
                { label: 'Jan', total_tf: 10, ocm_overall: 15 },
                { label: 'Feb', total_tf: 20, ocm_overall: 25 },
                { label: 'Mar', total_tf: 15, ocm_overall: 20 }
            ],
            metrics: {}
        };
    } finally {
        spinners.forEach(spinner => spinner.style.display = 'none');
    }
};

// Theme and UI Controls
const cycleTheme = () => {
    currentTheme = themes[(themes.indexOf(currentTheme) + 1) % themes.length];
    document.body.className = currentTheme;
    refreshCharts();
};

const refreshCharts = () => {
    document.querySelectorAll('.card svg').forEach(svg => svg.remove());
    drawCharts();
};

const refreshData = async () => {
    document.querySelectorAll('.card svg').forEach(svg => svg.remove());
    await drawCharts();
};

const closeDetails = () => document.getElementById('details').classList.remove('open');

const switchTab = (id) => {
    document.querySelectorAll('.tab, .tab-content').forEach(el => el.classList.remove('active'));
    document.querySelector(`[onclick="switchTab('${id}')"]`).classList.add('active');
    document.getElementById(id).classList.add('active');
};

const exportToExcel = () => {
    try {
        const rows = document.querySelectorAll('#data-table-content tr');
        if (rows.length <= 1) throw new Error('No data to export');
        const csv = [...rows].map(row =>
            [...row.children].map(cell => `"${cell.textContent.replace(/"/g, '""')}"`).join(',')
        ).join('\n');
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'dashboard_data.csv';
        link.click();
        URL.revokeObjectURL(link.href);
    } catch (error) {
        console.error('Error exporting to CSV:', error);
        alert('Failed to export to CSV. Please ensure the table has data and try again.');
    }
};

// Chart Rendering
const createTooltip = () => {
    d3.select('.tooltip').remove();
    return d3.select('body')
        .append('div')
        .attr('class', 'tooltip')
        .style('position', 'fixed')
        .style('opacity', 0)
        .style('display', 'none')
        .style('pointer-events', 'none')
        .style('z-index', 9999)
        .style('background', getCSSVariable('--card'))
        .style('color', getCSSVariable('--fg'))
        .style('padding', '0.5rem')
        .style('font-size', getCSSVariable('--font-size-base'))
        .style('border-radius', '4px')
        .style('box-shadow', '0 2px 8px rgba(0, 0, 0, 0.15)')
        .style('border', `1px solid ${getCSSVariable('--card-border')}`);
};

const showDetails = (data, type, summary) => {
    if (!data?.length) {
        alert('No data available to display.');
        return;
    }

    const container = document.getElementById('details');
    if (container.classList.contains('open')) {
        container.classList.remove('open');
        return;
    }

    document.getElementById('overview-text').textContent = summary;
    const tableBody = document.querySelector('#data-table-content tbody');
    tableBody.innerHTML = data.map(d => `
        <tr>
            <td>${d.label || 'N/A'}</td>
            <td>${type === 'scatter' ?
            `TF: ${d.total_tf.toFixed(2)}, OCM: ${d.ocm_overall.toFixed(2)}` :
            `${(d.value ?? 'N/A').toFixed(2)}`}</td>
        </tr>
    `).join('');

    const alt = d3.select('#alt-chart-content');
    alt.selectAll('*').remove();
    const { width, height } = getResponsiveDimensions('#alt-chart-content');
    const svg = alt.append('svg').attr('viewBox', `0 0 ${width} ${Math.min(height, 200)}`);
    drawAltChart(svg, data, width, Math.min(height, 200), type);
    switchTab('data-table');
    container.classList.add('open');
};

const createChartBase = (svg, width, height, x, y, fontScale) => {
    const { margin } = chartConfig;

    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).tickSize(-height + margin.top + margin.bottom).tickFormat(''))
        .selectAll('line')
        .attr('stroke', getCSSVariable('--grid'))
        .attr('stroke-opacity', 0.3)
        .attr('stroke-dasharray', '2,2');

    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(y).tickSize(-width + margin.left + margin.right).tickFormat(''))
        .selectAll('line')
        .attr('stroke', getCSSVariable('--grid'))
        .attr('stroke-opacity', 0.3)
        .attr('stroke-dasharray', '2,2');

    svg.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).ticks(3).tickPadding(8))
        .selectAll('text')
        .attr('dy', '1em')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${12 * fontScale}px`)
        .attr('transform', 'rotate(-30)')
        .attr('text-anchor', 'end');

    svg.append('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(y).ticks(8).tickFormat(d => d.toFixed(1)))
        .selectAll('text')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${12 * fontScale}px`);
};

const drawCharts = async () => {
    const data = await fetchData();
    const charts = [
        { id: '#line-chart', data: data.lineData, title: 'ID Count Trend', colors: ['#4c51bf', '#434190'], type: 'line', gradientId: 'lineGradient' },
        { id: '#bar-chart', data: data.barData, title: 'GF Count by Month', colors: ['#38a169', '#2f855a'], type: 'bar', gradientId: 'barGradient' },
        { id: '#area-chart', data: data.areaData, title: 'GFC Count Growth', colors: ['#ed8936', '#dd6b20'], type: 'area', gradientId: 'areaGradient' },
        {
            id: '#scatter-chart', data: data.scatterData, title: 'ID Distribution',
            colors: [['#4c51bf', '#434190'], ['#e53e3e', '#c53030']], type: 'scatter', gradientId: 'scatterGradient'
        }
    ];

    charts.forEach(chart => {
        switch (chart.type) {
            case 'line':
                drawLineChart(chart.id, chart.data, chart.title, chart.colors, chart.gradientId);
                break;
            case 'bar':
                drawBarChart(chart.id, chart.data, chart.title, chart.colors, chart.gradientId);
                break;
            case 'area':
                drawAreaChart(chart.id, chart.data, chart.title, chart.colors, chart.gradientId);
                break;
            case 'scatter':
                drawScatterChart(chart.id, chart.data, chart.title, chart.colors[0], chart.colors[1], chart.gradientId);
                break;
        }
    });
};

const createChartEffects = (svg, colors, gradientId) => {
    const defs = svg.append('defs');

    const gradient = defs.append('linearGradient')
        .attr('id', gradientId)
        .attr('x1', '0%').attr('y1', '0%').attr('x2', '0%').attr('y2', '100%');
    gradient.append('stop').attr('offset', '0%').style('stop-color', colors[0]).style('stop-opacity', 0.8);
    gradient.append('stop').attr('offset', '50%').style('stop-color', colors[1]).style('stop-opacity', 0.4);
    gradient.append('stop').attr('offset', '100%').style('stop-color', colors[0]).style('stop-opacity', 0.1);

    const shadow = defs.append('filter').attr('id', 'shadow');
    shadow.append('feDropShadow')
        .attr('dx', 0)
        .attr('dy', 2)
        .attr('stdDeviation', 3)
        .attr('flood-color', 'rgba(0,0,0,0.2)');

    const glow = defs.append('filter').attr('id', 'glow');
    glow.append('feGaussianBlur').attr('stdDeviation', '3').attr('result', 'coloredBlur');
    const feMerge = glow.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');
};

const drawLineChart = (container, data, title, colors, gradientId) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }

    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container)
        .append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${14 * fontScale}px`);

    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createChartEffects(svg, colors, gradientId);

    const area = d3.area()
        .x(d => x(d.label))
        .y0(height - margin.bottom)
        .y1(d => y(d.value))
        .curve(d3.curveMonotoneX);

    svg.append('path')
        .datum(data)
        .attr('fill', `url(#${gradientId})`)
        .attr('d', area)
        .style('filter', 'url(#shadow)')
        .attr('opacity', 0)
        .transition()
        .duration(chartConfig.animationDuration)
        .attr('opacity', 1);

    const line = d3.line().x(d => x(d.label)).y(d => y(d.value)).curve(d3.curveMonotoneX);
    svg.append('path')
        .datum(data)
        .attr('stroke', colors[0])
        .attr('stroke-width', 3)
        .attr('fill', 'none')
        .attr('d', line)
        .style('filter', 'url(#glow)')
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition()
        .duration(chartConfig.animationDuration)
        .attr('stroke-dashoffset', 0);

    svg.selectAll('circle')
        .data(data)
        .enter()
        .append('circle')
        .attr('cx', d => x(d.label))
        .attr('cy', d => y(d.value))
        .attr('r', 0)
        .attr('fill', colors[0])
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .style('filter', 'url(#shadow)')
        .style('cursor', 'pointer')
        .on('mouseover', function (event, d) {
            const xPos = Math.min(event.pageX + 15, window.innerWidth - 220);
            d3.select('.tooltip')
                .style('display', 'block')
                .transition()
                .duration(200)
                .style('opacity', 0.9)
                .html(`<b>${d.label}</b><br>Value: ${d.value.toFixed(1)}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`)
                .style('top', `${event.pageY - 40}px`);
        })
        .on('mouseout', function () {
            d3.select('.tooltip')
                .transition()
                .duration(300)
                .style('opacity', 0)
                .on('end', () => d3.select('.tooltip').style('display', 'none'));
        })

        .transition()
        .duration(chartConfig.animationDuration / 2)
        .delay((d, i) => i * 200)
        .attr('r', 7);

    svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${width - 100 * fontScale}, ${margin.top})`)
        .append('g')
        .attr('class', 'legend-item')
        .call(g => {
            g.append('rect')
                .attr('class', 'legend-color')
                .attr('fill', colors[0]);
            g.append('text')
                .attr('x', 20)
                .attr('y', 10)
                .attr('fill', getCSSVariable('--fg'))
                .text('ID Count');
        });

    svg.on('click', () => showDetails(data, 'line', `Trend of ${title} over time.`));
};

const drawBarChart = (container, data, title, colors, gradientId) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }

    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container)
        .append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${14 * fontScale}px`);

    const { margin } = chartConfig;
    const x = d3.scaleBand().domain(data.map(d => d.label)).range([margin.left, width - margin.right]).padding(0.2);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createChartEffects(svg, colors, gradientId);

    svg.selectAll('rect')
        .data(data)
        .enter()
        .append('rect')
        .attr('x', d => x(d.label))
        .attr('y', d => y(0))
        .attr('width', x.bandwidth())
        .attr('height', 0)
        .attr('fill', `url(#${gradientId})`)
        .attr('rx', 8)
        .attr('ry', 8)
        .style('filter', 'url(#shadow)')
        .style('cursor', 'pointer')
        .on('mouseover', function (event, d) {
            const xPos = Math.min(event.pageX + 15, window.innerWidth - 220);
            d3.select('.tooltip')
                .style('display', 'block')
                .transition()
                .duration(200)
                .style('opacity', 0.9)
                .html(`<b>${d.label}</b><br>Value: ${d.value.toFixed(1)}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`)
                .style('top', `${event.pageY - 40}px`);
        })
        .on('mouseout', function () {
            d3.select('.tooltip')
                .transition()
                .duration(300)
                .style('opacity', 0)
                .on('end', () => d3.select('.tooltip').style('display', 'none'));
        })

        .transition()
        .duration(chartConfig.animationDuration)
        .delay((d, i) => i * 250)
        .attr('y', d => y(d.value))
        .attr('height', d => height - margin.bottom - y(d.value));

    svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${width - 100 * fontScale}, ${margin.top})`)
        .append('g')
        .attr('class', 'legend-item')
        .call(g => {
            g.append('rect')
                .attr('class', 'legend-color')
                .attr('fill', colors[0]);
            g.append('text')
                .attr('x', 20)
                .attr('y', 10)
                .attr('fill', getCSSVariable('--fg'))
                .text('GF Count');
        });

    svg.on('click', () => showDetails(data, 'bar', `Distribution of ${title} over time.`));
};

const drawAreaChart = (container, data, title, colors, gradientId) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }

    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container)
        .append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${14 * fontScale}px`);

    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    createChartBase(svg, width, height, x, y, fontScale);
    createChartEffects(svg, colors, gradientId);

    const area = d3.area()
        .x(d => x(d.label))
        .y0(height - margin.bottom)
        .y1(d => y(d.value))
        .curve(d3.curveMonotoneX);

    svg.append('path')
        .datum(data)
        .attr('fill', `url(#${gradientId})`)
        .attr('d', area)
        .style('filter', 'url(#shadow)')
        .attr('opacity', 0)
        .transition()
        .duration(chartConfig.animationDuration)
        .attr('opacity', 1);

    const line = d3.line().x(d => x(d.label)).y(d => y(d.value)).curve(d3.curveMonotoneX);
    svg.append('path')
        .datum(data)
        .attr('stroke', colors[0])
        .attr('stroke-width', 3)
        .attr('fill', 'none')
        .attr('d', line)
        .style('filter', 'url(#glow)')
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition()
        .duration(chartConfig.animationDuration)
        .attr('stroke-dashoffset', 0);

    svg.selectAll('circle')
        .data(data)
        .enter()
        .append('circle')
        .attr('cx', d => x(d.label))
        .attr('cy', d => y(d.value))
        .attr('r', 0)
        .attr('fill', colors[0])
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .style('filter', 'url(#shadow)')
        .style('cursor', 'pointer')
        .on('mouseover', function (event, d) {
            const xPos = Math.min(event.pageX + 15, window.innerWidth - 220);
            d3.select('.tooltip')
                .style('display', 'block')
                .transition()
                .duration(200)
                .style('opacity', 0.9)
                .html(`<b>${d.label}</b><br>Value: ${d.value.toFixed(1)}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`)
                .style('top', `${event.pageY - 40}px`);
        })
        .on('mouseout', function () {
            d3.select('.tooltip')
                .transition()
                .duration(300)
                .style('opacity', 0)
                .on('end', () => d3.select('.tooltip').style('display', 'none'));
        })

        .transition()
        .duration(chartConfig.animationDuration / 2)
        .delay((d, i) => i * 200)
        .attr('r', 7);

    svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${width - 100 * fontScale}, ${margin.top})`)
        .append('g')
        .attr('class', 'legend-item')
        .call(g => {
            g.append('rect')
                .attr('class', 'legend-color')
                .attr('fill', colors[0]);
            g.append('text')
                .attr('x', 20)
                .attr('y', 10)
                .attr('fill', getCSSVariable('--fg'))
                .text('GFC Count');
        });

    svg.on('click', () => showDetails(data, 'area', `Growth of ${title} over time.`));
};

const drawScatterChart = (container, data, title, colorsTF, colorsOCM, gradientId) => {
    if (!data?.length) {
        d3.select(container).append('text')
            .attr('x', '50%')
            .attr('y', '50%')
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }

    const { width, height, fontScale } = getResponsiveDimensions(container);
    const svg = d3.select(container)
        .append('svg')
        .attr('viewBox', `0 0 ${width} ${height}`)
        .style('font-size', `${14 * fontScale}px`);

    const { margin } = chartConfig;
    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const yTF = d3.scaleLinear().domain([0, d3.max(data, d => d.total_tf) * 1.2]).nice().range([height - margin.bottom, margin.top]);
    const yOCM = d3.scaleLinear().domain([0, d3.max(data, d => d.ocm_overall) * 1.2]).nice().range([height - margin.bottom, margin.top]);

    let tfVisible = true;
    let ocmVisible = true;

    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).ticks(3).tickSize(-height + margin.top + margin.bottom).tickFormat(''))
        .selectAll('line').attr('stroke', getCSSVariable('--grid')).attr('stroke-opacity', 0.3).attr('stroke-dasharray', '2,2');

    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(yTF).tickSize(-width + margin.left + margin.right).tickFormat(''))
        .selectAll('line').attr('stroke', getCSSVariable('--grid')).attr('stroke-opacity', 0.3).attr('stroke-dasharray', '2,2');

    svg.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).ticks(3).tickPadding(8))
        .selectAll('text')
        .attr('dy', '1em')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${12 * fontScale}px`)
        .attr('transform', 'rotate(-30)')
        .attr('text-anchor', 'end');

    svg.append('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(yTF).ticks(8).tickFormat(d => d.toFixed(1)))
        .selectAll('text')
        .attr('fill', colorsTF[0])
        .style('font-size', `${12 * fontScale}px`);

    svg.append('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${width - margin.right + 10}, 0)`)
        .call(d3.axisRight(yOCM).ticks(8).tickFormat(d => d.toFixed(1)).tickPadding(20))
        .selectAll('text')
        .attr('fill', colorsOCM[0])
        .style('font-size', `${12 * fontScale}px`);

    const defs = svg.append('defs');
    const backgroundGradient = defs.append('linearGradient')
        .attr('id', 'chartBackground')
        .attr('x1', '0%').attr('y1', '0%').attr('x2', '0%').attr('y2', '100%');
    backgroundGradient.append('stop').attr('offset', '0%').style('stop-color', 'rgba(255,255,255,0.05)').style('stop-opacity', 1);
    backgroundGradient.append('stop').attr('offset', '100%').style('stop-color', 'rgba(255,255,255,0.02)').style('stop-opacity', 1);
    svg.append('rect')
        .attr('x', 0)
        .attr('y', 0)
        .attr('width', width)
        .attr('height', height)
        .attr('fill', 'url(#chartBackground)');

    createChartEffects(svg, colorsTF, gradientId);

    const lineTF = d3.line().x(d => x(d.label)).y(d => yTF(d.total_tf)).curve(d3.curveMonotoneX);
    const lineOCM = d3.line().x(d => x(d.label)).y(d => yOCM(d.ocm_overall)).curve(d3.curveMonotoneX);

    const tfLine = svg.append('path')
        .datum(data)
        .attr('class', 'tf-line')
        .attr('stroke', colorsTF[0])
        .attr('stroke-width', 3)
        .attr('fill', 'none')
        .attr('d', lineTF)
        .style('filter', 'url(#glow)')
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition()
        .duration(chartConfig.animationDuration)
        .attr('stroke-dashoffset', 0);

    const ocmLine = svg.append('path')
        .datum(data)
        .attr('class', 'ocm-line')
        .attr('stroke', colorsOCM[0])
        .attr('stroke-width', 3)
        .attr('fill', 'none')
        .attr('d', lineOCM)
        .style('filter', 'url(#glow)')
        .attr('stroke-dasharray', function () { return this.getTotalLength(); })
        .attr('stroke-dashoffset', function () { return this.getTotalLength(); })
        .transition()
        .duration(chartConfig.animationDuration)
        .attr('stroke-dashoffset', 0);

    const tfDots = svg.selectAll('.dot-tf')
        .data(data)
        .enter()
        .append('circle')
        .attr('class', 'dot-tf')
        .attr('cx', d => x(d.label))
        .attr('cy', d => yTF(d.total_tf))
        .attr('r', 0)
        .attr('fill', colorsTF[0])
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .style('filter', 'url(#shadow)')
        .style('cursor', 'pointer')
        .on('mouseover', function (event, d) {
            const xPos = Math.min(event.pageX + 15, window.innerWidth - 220);
            d3.select('.tooltip')
                .style('display', 'block')
                .transition()
                .duration(200)
                .style('opacity', 0.9)
                .html(`<b>${d.label}</b><br>Value: ${d.value.toFixed(1)}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`)
                .style('top', `${event.pageY - 40}px`);
        })
        .on('mouseout', function () {
            d3.select('.tooltip')
                .transition()
                .duration(300)
                .style('opacity', 0)
                .on('end', () => d3.select('.tooltip').style('display', 'none'));
        })

        .transition()
        .duration(chartConfig.animationDuration / 2)
        .delay((d, i) => i * 200)
        .attr('r', 6);

    const ocmDots = svg.selectAll('.dot-ocm')
        .data(data)
        .enter()
        .append('circle')
        .attr('class', 'dot-ocm')
        .attr('cx', d => x(d.label))
        .attr('cy', d => yOCM(d.ocm_overall))
        .attr('r', 0)
        .attr('fill', colorsOCM[0])
        .attr('stroke', '#fff')
        .attr('stroke-width', 2)
        .style('filter', 'url(#shadow)')
        .style('cursor', 'pointer')
        .on('mouseover', function (event, d) {
            const xPos = Math.min(event.pageX + 15, window.innerWidth - 220);
            d3.select('.tooltip')
                .style('display', 'block')
                .transition()
                .duration(200)
                .style('opacity', 0.9)
                .html(`<b>${d.label}</b><br>Value: ${d.value.toFixed(1)}<br>Trend: ${d.value > (data[data.indexOf(d) - 1]?.value || 0) ? '↑' : '↓'}`)
                .style('left', `${xPos}px`)
                .style('top', `${event.pageY - 40}px`);
        })
        .on('mouseout', function () {
            d3.select('.tooltip')
                .transition()
                .duration(300)
                .style('opacity', 0)
                .on('end', () => d3.select('.tooltip').style('display', 'none'));
        })

        .transition()
        .duration(chartConfig.animationDuration / 2)
        .delay((d, i) => i * 200)
        .attr('r', 6);

    svg.append('g')
        .attr('class', 'legend')
        .attr('transform', `translate(${width - 120 * fontScale}, ${margin.top})`)
        .call(g => {
            const tfLegend = g.append('g')
                .attr('class', 'legend-item')
                .style('cursor', 'pointer')
                .on('click', () => {
                    tfVisible = !tfVisible;
                    tfLine.attr('opacity', tfVisible ? 1 : 0);
                    tfDots.attr('opacity', tfVisible ? 1 : 0);
                    tfLegend.select('rect').attr('opacity', tfVisible ? 1 : 0.3);
                });
            tfLegend.append('rect')
                .attr('class', 'legend-color')
                .attr('fill', colorsTF[0]);
            tfLegend.append('text')
                .attr('x', 20)
                .attr('y', 10)
                .attr('fill', getCSSVariable('--fg'))
                .text('Total TF');

            const ocmLegend = g.append('g')
                .attr('class', 'legend-item')
                .attr('transform', 'translate(0, 20)')
                .style('cursor', 'pointer')
                .on('click', () => {
                    ocmVisible = !ocmVisible;
                    ocmLine.attr('opacity', ocmVisible ? 1 : 0);
                    ocmDots.attr('opacity', ocmVisible ? 1 : 0);
                    ocmLegend.select('rect').attr('opacity', ocmVisible ? 1 : 0.3);
                });
            ocmLegend.append('rect')
                .attr('class', 'legend-color')
                .attr('fill', colorsOCM[0]);
            ocmLegend.append('text')
                .attr('x', 20)
                .attr('y', 10)
                .attr('fill', getCSSVariable('--fg'))
                .text('OCM Overall');
        });

    svg.on('click', () => showDetails(data, 'scatter', `Distribution of ${title} over time.`));
};

const drawAltChart = (svg, data, width, height, type) => {
    if (!data?.length) {
        svg.append('text')
            .attr('x', width / 2)
            .attr('y', height / 2)
            .attr('text-anchor', 'middle')
            .attr('fill', getCSSVariable('--fg'))
            .text('No data available');
        return;
    }

    const fontScale = Math.min(1, width / 400);
    svg.style('font-size', `${12 * fontScale}px`);
    const { margin } = chartConfig;

    const x = d3.scalePoint().domain(data.map(d => d.label)).range([margin.left, width - margin.right]);
    const maxValue = d3.max(data, d => d.value || Math.max(d.total_tf || 0, d.ocm_overall || 0)) * 1.1 || 100;
    const y = d3.scaleLinear()
        .domain([0, maxValue])
        .nice()
        .range([height - margin.bottom, margin.top]);

    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).tickSize(-height + margin.top + margin.bottom).tickFormat(''))
        .selectAll('line')
        .attr('stroke', getCSSVariable('--grid'))
        .attr('stroke-opacity', 0.3)
        .attr('stroke-dasharray', '2,2');

    svg.append('g')
        .attr('class', 'grid')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(y).tickSize(-width + margin.left + margin.right).tickFormat(''))
        .selectAll('line')
        .attr('stroke', getCSSVariable('--grid'))
        .attr('stroke-opacity', 0.3)
        .attr('stroke-dasharray', '2,2');

    svg.append('g')
        .attr('class', 'x-axis')
        .attr('transform', `translate(0, ${height - margin.bottom})`)
        .call(d3.axisBottom(x).ticks(3).tickPadding(8))
        .selectAll('text')
        .attr('dy', '1em')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${12 * fontScale}px`)
        .attr('transform', 'rotate(-30)')
        .attr('text-anchor', 'end');

    svg.append('g')
        .attr('class', 'y-axis')
        .attr('transform', `translate(${margin.left}, 0)`)
        .call(d3.axisLeft(y).ticks(8).tickFormat(d => d.toFixed(1)))
        .selectAll('text')
        .attr('fill', getCSSVariable('--fg'))
        .style('font-size', `${12 * fontScale}px`);

    const defs = svg.append('defs');
    const gradient = defs.append('linearGradient')
        .attr('id', 'altGradient')
        .attr('x1', '0%').attr('y1', '0%').attr('x2', '0%').attr('y2', '100%');
    gradient.append('stop').attr('offset', '0%').style('stop-color', getCSSVariable('--accent')).style('stop-opacity', 0.8);
    gradient.append('stop').attr('offset', '100%').style('stop-color', getCSSVariable('--accent')).style('stop-opacity', 0.3);

    const area = d3.area()
        .x(d => x(d.label))
        .y0(height - margin.bottom)
        .y1(d => y(d.value || Math.max(d.total_tf || 0, d.ocm_overall || 0)))
        .curve(d3.curveMonotoneX);

    svg.append('path')
        .datum(data)
        .attr('fill', 'url(#altGradient)')
        .attr('opacity', 0.6)
        .attr('d', area)
        .style('filter', 'url(#shadow)')
        .transition()
        .duration(chartConfig.animationDuration / 2)
        .attr('opacity', 1);
};

// Event Handling
const debounce = (func, wait) => {
    let timeout;
    return (...args) => {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
};

const initializeCharts = () => {
    createTooltip();
    refreshCharts();
};

// Initialize
document.addEventListener('DOMContentLoaded', initializeCharts);
window.addEventListener('resize', debounce(initializeCharts, 200));