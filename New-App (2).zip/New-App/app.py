from flask import Flask, render_template, jsonify
from datetime import datetime, timedelta
import random

app = Flask(__name__)


def generate_time_series():
    now = datetime.now()
    return [
        {
            "month_end": (now - timedelta(days=30 * i)).strftime("%b '%y"),
            "count_id": random.randint(100, 230),
            "count_gf": random.randint(80, 135),
            "count_gfc": random.randint(100, 210),
            "total_tf": round(random.uniform(2.5, 3.7), 2),
            "ocm_overall": round(random.uniform(1.5, 2.05), 2),
        }
        for i in range(12, 0, -1)
    ]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/data")
def get_data():
    data = generate_time_series()
    # Extract current and previous month data for trends
    current_month = data[0]  # Most recent month
    prev_month = data[1] if len(data) > 1 else None  # Previous month

    # Calculate trends
    trends = {
        "count_id_trend": (
            "↑"
            if prev_month and current_month["count_id"] > prev_month["count_id"]
            else "↓"
        ),
        "count_gf_trend": (
            "↑"
            if prev_month and current_month["count_gf"] > prev_month["count_gf"]
            else "↓"
        ),
        "count_gfc_trend": (
            "↑"
            if prev_month and current_month["count_gfc"] > prev_month["count_gfc"]
            else "↓"
        ),
    }

    return jsonify(
        {
            "lineData": [
                {"label": d["month_end"], "value": d["count_id"]} for d in data
            ],
            "barData": [
                {"label": d["month_end"], "value": d["count_gf"]} for d in data
            ],
            "areaData": [
                {"label": d["month_end"], "value": d["count_gfc"]} for d in data
            ],
            "scatterData": [
                {
                    "label": d["month_end"],
                    "total_tf": d["total_tf"],
                    "ocm_overall": d["ocm_overall"],
                }
                for d in data
            ],
            "metrics": {
                "totalAssault": 187001,
                "amountDeposit": 21345,
                "amountEprint": 7321,
                "expectedAmount": 81987,
                "current_metrics": {
                    "count_id": current_month["count_id"],
                    "count_gf": current_month["count_gf"],
                    "count_gfc": current_month["count_gfc"],
                    "trends": trends,
                },
            },
        }
    )


if __name__ == "__main__":
    app.run(debug=True)
